local new = false
local allowed = flase
local screenshotlink
local screenshotted = false

local Config = {}
local LMConfig = {}

Citizen.CreateThread(function()
    Wait(10000)
    TriggerServerEvent('SkeezeAnticheat:NJkidfjxiuUI-D')
end)

RegisterNetEvent('SkEzAEKzeAnSIjdCajudChejadT:AutH.dhoriM-kzed')
AddEventHandler('SkEzAEKzeAnSIjdCajudChejadT:AutH.dhoriM-kzed', function(GetConfig, ServerSidedConfig, BooleanCheck)
    if BooleanCheck then
        Config = GetConfig
        LMConfig = ServerSidedConfig
        RunClientSided()
    end
end)

RunClientSided = function()
    -- Anti NUI Devtools
    RegisterNUICallback(GetCurrentResourceName(), function()
        TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'nuidevtools')
    end)

    -- Anti Weapon Pickup
    Citizen.CreateThread(function() 
        while true do  
            Wait(50)  
            if Config.AntiWeaponPickup ~= true then return end
            RemoveAllPickupsOfType(GetHashKey("PICKUP_ARMOUR_STANDARD")) 
            RemoveAllPickupsOfType(GetHashKey("PICKUP_VEHICLE_ARMOUR_STANDARD"))
            RemoveAllPickupsOfType(GetHashKey("PICKUP_HEALTH_SNACK"))
            RemoveAllPickupsOfType(GetHashKey("PICKUP_HEALTH_STANDARD"))
            RemoveAllPickupsOfType(GetHashKey("PICKUP_VEHICLE_HEALTH_STANDARD"))
            RemoveAllPickupsOfType(GetHashKey("PICKUP_VEHICLE_HEALTH_STANDARD_LOW_GLOW"))
            
        end
    end)

    -- Anti Vision
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(2500)
            if GetUsingnightvision(true) then
                if LMConfig.AntiNightVision.Enabled ~= true then return end
                ScreenShotToDiscord('Anti Thermal Vision')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'nightvision', screenshotlink)
                    screenshotted = false
                end
            end
            if GetUsingseethrough(true) then
                if LMConfig.AntiThermalVision.Enabled ~= true then return end
                ScreenShotToDiscord('Anti Vision')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'thermalvision', screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)

    -- Anti Spectate
    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiSpectate.Enabled ~= true then return end
            Citizen.Wait(1500)
            if NetworkIsInSpectatorMode() then
                ScreenShotToDiscord('Anti Spectate')
                Wait(750)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'spectate', screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)

    -- Anti Freecam
    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiFreecam.Enabled ~= true then return end
            if new == false then
                Wait(5000)
                new = true
            end
            Citizen.Wait(2500)
            local ped = GetPlayerPed(-1)
            local camcoords = (GetEntityCoords(ped) - GetFinalRenderedCamCoord())
            if (camcoords.x > 50) or (camcoords.y > 50) or (camcoords.z > 50) or (camcoords.x < -50) or (camcoords.y < -50) or (camcoords.z < -50) then
                ScreenShotToDiscord('Anti Freecam')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'Freecam', screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)

    Citizen.CreateThread(function()
        while true do
            if new == false then
                Wait(3000)
                new = true
            end
            if LMConfig.AntiInvisible.Enabled ~= true then return end
            Citizen.Wait(5000)
            local ped = GetPlayerPed(-1)
            local entityalpha = GetEntityAlpha(ped)
            if not IsEntityVisible(ped) or not IsEntityVisibleToScript(ped) or entityalpha <= 150 then
                ScreenShotToDiscord('Anti Invisible')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'invisible', screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)

    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiExplosionBullet.Enabled ~= true then return end
            Citizen.Wait(5000)
            local weapondamage = GetWeaponDamageType(GetSelectedPedWeapon(_ped))
            if weapondamage == 4 or weapondamage == 5 or weapondamage == 6 or weapondamage == 13 then
                ScreenShotToDiscord('Anti Explosion Bullet')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'explosionbullet', screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)

    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiTeleport.Enabled ~= true then return end
            Citizen.Wait(2500)
            local ped = GetPlayerPed(-1)
            local coords1x,coords1y,coords1z = table.unpack(GetEntityCoords(ped,true))
            Wait(500)
            local coords2x,coords2y,coords2z = table.unpack(GetEntityCoords(ped,true))
            if GetDistanceBetweenCoords(coords1x,coords1y,coords1z, coords2x,coords2y,coords2z) > 500 then
                if IsPedFalling(ped) then return end
                if IsPedInAnyVehicle(ped) then return end
                ScreenShotToDiscord('Anti Teleport')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'teleport', screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)

    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiNoclip.Enabled ~= true then return end
            Citizen.Wait(1)
            local _ped = PlayerPedId()
            local _Wait = Citizen.Wait
            if not IsPedInAnyVehicle(_ped, false) then
                local _pos = GetEntityCoords(_ped)
                _Wait(1000)
                local _newped = PlayerPedId()
                local _newpos = GetEntityCoords(_newped)
                local _distance = #(vector3(_pos) - vector3(_newpos))
                if _distance > 30 and not IsEntityDead(_ped) and not IsPedInParachuteFreeFall(_ped) and _ped == _newped then
                    ScreenShotToDiscord('Anti Noclip')
                    Wait(750)
                    if screenshotted then
                        TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'noclip', screenshotlink)
                        screenshotted = false
                    end
                end
            end
        end
    end)

    Citizen.CreateThread(function ()
        while true do
            if LMConfig.SuperJump.Enabled ~= true then return end
            local ped = PlayerPedId()
            Citizen.Wait(810)
            if IsPedJumping(ped) then
                TriggerServerEvent('5a1Ltc8fUyH3cPvAKRZ8DX')
            end
        end
    end)

    RegisterNetEvent('esx:getSharedObject')
    AddEventHandler('esx:getSharedObject', function()
        if Config.AntiESX ~= true then return end
        ScreenShotToDiscord('Anti ')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:banXD', 'ESX Cheat detected.', screenshotlink)
                    screenshotted = false
                end
    end)

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(500)
            if Config.BlacklistedWeapons then
                for _,theWeapon in ipairs(Config.BlacklistedWeaponsList) do
                    Wait(5)
                    --print(theWeapon)
                    --print(GetHashKey(theWeapon))
                    local ped = GetPlayerPed(-1)
                    if HasPedGotWeapon(PlayerPedId(),GetHashKey(theWeapon),false) == 1 then
                        RemoveAllPedWeapons(ped)
                        Citizen.Wait(10)
                        if Config.BlacklistedWeaponsBan then
                            ScreenShotToDiscord('Blacklisted Weapon')
                            Wait(450)
                            if screenshotted then
                                TriggerServerEvent('anticheat:banXD', 'Blacklisted Weapon detected.', screenshotlink)
                                screenshotted = false
                            end
                        end
                    end
                end
            end
        end
    end)

    -- Anti Vehicle Modifier
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(2500)
            local ped = PlayerPedId()
            local sleep = true
            if IsPedInAnyVehicle(ped, false) then
                sleep = false
                local vehiclein = GetVehiclePedIsIn(ped, 0)
                if IsVehicleDamaged(vehiclein) then
                    if GetEntityHealth(vehiclein) >= GetEntityMaxHealth(vehiclein) then
                        if Config.VehicleGodMode then
                            if GetVehiclePedIsIn(GetPlayerPed(-1)) then return end
                            ScreenShotToDiscord('Vehicle Speed')
                            Wait(450)
                            if screenshotted then
                                TriggerServerEvent('anticheat:banXD', 'Vehicle-Modifier detected.', screenshotlink)
                                screenshotted = false
                            end
                            DeleteEntity(vehiclein)
                        end
                    end
                end
                SetEntityInvincible(vehiclein, false)
                if GetVehicleCheatPowerIncrease(vehiclein) > 1.0 then
                    if Config.VehiclePowerIncrease then
                        if GetVehiclePedIsIn(GetPlayerPed(-1)) then return end
                        ScreenShotToDiscord('Vehicle Speed')
                        Wait(450)
                        if screenshotted then
                            TriggerServerEvent('anticheat:banXD', 'Vehicle-Modifier detected.', screenshotlink)
                            screenshotted = false
                        end
                        DeleteEntity(vehiclein)
                    end
                end
                if GetVehicleTopSpeedModifier(vehiclein) > -1.0 then
                    if Config.VehicleSpeedHack then
                        if GetVehiclePedIsIn(GetPlayerPed(-1)) then return end
                        ScreenShotToDiscord('Vehicle Speed')
                        Wait(450)
                        if screenshotted then
                            TriggerServerEvent('anticheat:banXD', 'Vehicle-Modifier detected.', screenshotlink)
                            screenshotted = false
                        end
                        DeleteEntity(vehiclein)
                    end
                end
                SetVehicleTyresCanBurst(vehiclein, true)
            end
        end
    end)

    -- Anti Infinite Ammo
    Citizen.CreateThread(function()
        while true do
            if Config.AntiInfiniteAmmo ~= true then return end
            Wait(10)
            SetPedInfiniteAmmoClip(_ped, false)
        end
    end)

    -- Anti GodMode2
    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiGodMode.Enabled ~= true then return end
            Wait(760)
            local ped = PlayerPedId()

            if GetPlayerInvincible(ped) then
                ScreenShotToDiscord('Anti Godmode')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'godmode2', screenshotlink)
                    screenshotted = false
                end
            elseif GetPlayerInvincible_2(ped) then
                ScreenShotToDiscord('Anti Godmode')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'godmode2', screenshotlink)
                    screenshotted = false
                end
            end

            if GetPlayerInvincible(ped) then
                ScreenShotToDiscord('Anti Godmode')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'godmode2', screenshotlink)
                    screenshotted = false
                end
                SetPlayerInvincible(ped, false)
            end
        end
    end)

    -- Anti GodMode3+4
    CreateThread(function()
        while true do
        if LMConfig.AntiGodMode.Enabled ~= true then return end
        Wait(3000)
            if GetPlayerInvincible_2(PlayerId()) then
                ScreenShotToDiscord('Anti Godmode')
                Wait(450)
                if screenshotted then
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'godmode3', screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)



    -- Screenshot
    RegisterNetEvent("anticheat:screenshot")
    AddEventHandler("anticheat:screenshot", function(reason)
        ScreenShotToDiscord(reason)
        Wait(650)
        if screenshotted then
            TriggerServerEvent('anticheat:xMkdMoklIefalxK', reason, screenshotlink)
            screenshotted = false
        end
    end)

    -- Anti Damage Modifier
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)
            local _ped = PlayerPedId()
            local _sleep = true
            if IsPedArmed(_ped, 6) then
                _sleep = false
                local weaponselected = GetSelectedPedWeapon(_ped)
                local _pid = PlayerId()
                local _Wait = Citizen.Wait
                if GetWeaponDamageModifier(weaponselected) > 1.0 then
                    TriggerServerEvent("anticheat:xMkdMoklIefalxK", "damagemodifier")
                    _Wait(1500)
                end
                if GetPlayerWeaponDamageModifier(_pid) > 1.0 then
                    TriggerServerEvent("anticheat:xMkdMoklIefalxK", "damagemodifier")
                    _Wait(1500)
                end
                if GetPlayerMeleeWeaponDamageModifier(_pid) > 1.0 then
                    TriggerServerEvent("anticheat:xMkdMoklIefalxK", "damagemodifier")
                    _Wait(1500)
                end
                if GetPlayerMeleeWeaponDefenseModifier(_pid) > 1.0 then
                    TriggerServerEvent("anticheat:xMkdMoklIefalxK", "damagemodifier")
                    _Wait(1500)
                end
                if GetPlayerWeaponDefenseModifier(_pid) > 1.0 then
                    TriggerServerEvent("anticheat:xMkdMoklIefalxK", "damagemodifier")
                    _Wait(1500)
                end
                if GetPlayerWeaponDefenseModifier_2(_pid) > 1.0 then
                    TriggerServerEvent("anticheat:xMkdMoklIefalxK", "damagemodifier")
                    _Wait(1500)
                end
                if IsAimCamActive() then
                    local _isaiming, _entity = GetEntityPlayerIsFreeAimingAt(_pid)
                    if _isaiming and _entity then
                        if IsEntityAPed(_entity) and not IsEntityDead(_entity) and not IsPedStill(_entity) and not IsPedStopped(_entity) and not IsPedInAnyVehicle(_entity, false) then
                            local _entitycoords = GetEntityCoords(_entity)
                            local retval, screenx, screeny = GetScreenCoordFromWorldCoord(_entitycoords.x, _entitycoords.y, _entitycoords.z)
                            if screenx == lastcoordsx or screeny == lastcoordsy then
                                    TriggerServerEvent("anticheat:xMkdMoklIefalxK", "aimbot")
                                    _Wait(1500)
                            end
                            lastcoordsx = screenx
                            lastcoordsy = screeny
                        end
                        if IsEntityAPed(_entity) and IsPedAPlayer(_entity) then
                            lastentityplayeraimedat = _entity
                        end
                    end
                    isarmed = true
                end
            end
            if _sleep then Citizen.Wait(840) isarmed = false end
        end
    end)



    AddEventHandler('onClientResourceStart', function (resourceName)
        if GetResourceState(resourceName) == "missing" or GetResourceState (resourceName) ==  "unknown" then
            TriggerServerEvent('anticheat:banXD', 'Anti Eulen!')
        end
    end)

    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiBlips.Enabled ~= true then return end
            Citizen.Wait(3000)
            local _pid = PlayerId()
            local _activeplayers = GetActivePlayers()
            for i = 1, #_activeplayers do
                if i ~= _pid then
                    if DoesBlipExist(GetBlipFromEntity(GetPlayerPed(i))) then
                        TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'blips')
                    end
                end
                Citizen.Wait(50)
            end
        end
    end)

    Citizen.CreateThread(function()
        local orginalped = GetEntityModel(_pid)

        while true do 
            if LMConfig.AntiSpeedrun.Enabled ~= true then return end
            local _pid = PlayerPedId()
            Wait(350)
                local fallin = IsPedFalling(_pid)
                local ragg = IsPedRagdoll(_pid)
                local parac = GetPedParachuteState(_pid)
                local pedVehicl = IsPedInAnyVehicle(PlayerPedId(), false)

                if parac >= 0 or ragg or fallin or pedVehicl then
                    SetEntityMaxSpeed(_pid, 80.0)
                else
                        ScreenShotToDiscord('Speedrun')
                        Wait(500)
                        if screenshotted then
                            local data = {
                                type = "Speedrun",
                                Speed = GetEntitySpeed(_pid)
                            }
                            TriggerServerEvent('anticheat:xMkdMoklIefalxK', data, screenshotlink)
                            screenshotted = false
                        end
                end

            if GetPedConfigFlag(_pid, 223, true) then 
                ScreenShotToDiscord('Speedrun')
                Wait(500)
                if screenshotted then
                    local data = {
                        type = "AntiPedModifier"
                    }
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', data, screenshotlink)
                    screenshotted = false
                end
            end
        end
    end)

    Citizen.CreateThread(function()
        while true do
            if LMConfig.AntiMaxArmour.Enabled ~= true then return end
                local ped = PlayerPedId()
                local armor = GetPedArmour(ped)
                ScreenShotToDiscord('Speedrun')
                Wait(500)
                if screenshotted then
                    local data = {
                        type = "AntiArmour",
                        Armour = armor
                    }
                    TriggerServerEvent('anticheat:xMkdMoklIefalxK', data, screenshotlink)
                    screenshotted = false
                end
            Citizen.Wait(1000)    
        end
    end)   

    function ScreenShotToDiscord(reason)
        exports['screenshot-basic']:requestScreenshotUpload('https://discord.com/api/webhooks/937356267675070495/qHje_3MJujuvYWOvtjzXiXo2r7m6_7PdMOLXU3sCYjHQUa-_gMS-ar4Bh80ytISdbKjp', "files[]", function(data)
            local image = json.decode(data)
            screenshotlink = image.attachments[1].proxy_url
            screenshotted = true
        end)
    end

    RegisterNetEvent("ZRQA3nmMqUBOIiKwH4I5:clearvehicles")
    AddEventHandler("ZRQA3nmMqUBOIiKwH4I5:clearvehicles", function(vehicles)
        if vehicles == nil then
            local vehs = GetGamePool('CVehicle')
            for _, vehicle in ipairs(vehs) do
                if not IsPedAPlayer(GetPedInVehicleSeat(vehicle, -1)) then
                    if NetworkGetEntityIsNetworked(vehicle) then
                        DeleteNetworkedEntity(vehicle)
                    else
                        SetVehicleHasBeenOwnedByPlayer(vehicle, false)
                        SetEntityAsMissionEntity(vehicle, true, true)
                        DeleteEntity(vehicle)
                    end
                end
            end
        else
                local vehs = GetGamePool('CVehicle')
                for _, vehicle in ipairs(vehs) do
                    local owner = NetworkGetEntityOwner(vehicle)
                    if owner ~= nil then
                        local _pid = GetPlayerServerId(owner)
                        if _pid == vehicles then
                            if not IsPedAPlayer(GetPedInVehicleSeat(vehicle, -1)) then
                                if NetworkGetEntityIsNetworked(vehicle) then
                                    DeleteNetworkedEntity(vehicle)
                                else
                                    SetVehicleHasBeenOwnedByPlayer(vehicle, false)
                                    SetEntityAsMissionEntity(vehicle, true, true)
                                    DeleteEntity(vehicle)
                                end
                            end
                        end
                    end
                end
        end
    end)

    AddEventHandler("onResourceStop", function(res)
        TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'AntiResourceStop')
        CancelEvent()
    end)
    
    AddEventHandler("onClientResourceStop", function(res)
        TriggerServerEvent('anticheat:xMkdMoklIefalxK', 'AntiResourceStop')
        CancelEvent()
    end)
    
    AddEventHandler("gameEventTriggered", function(a, b)
        if a == "CEventNetworkVehicleUndrivable" then
            DeleteEntity(table.unpack(b))
        end
    end)


    RegisterNetEvent("WipeVehicles")
    AddEventHandler("WipeVehicles", function(a)
        for fg, fh in pairs((GetGamePool(a))) do
            if (not IsPedAPlayer(GetPedInVehicleSeat(fh, -1))) then 
                DeleteEntity(fh)
            end
        end
    end)

    RegisterNetEvent("PropWipe")
    AddEventHandler("PropWipe", function(a)
        for fg, fh in pairs((GetGamePool(a))) do
            DeleteEntity(fh)
        end
    end)


        RegisterNetEvent('ZRQA3nmMqUBOIiKwH4I5:clearpeds')
        AddEventHandler('ZRQA3nmMqUBOIiKwH4I5:clearpeds', function()
                local _peds = GetGamePool('CPed')
                for _, ped in ipairs(_peds) do
                    if not (IsPedAPlayer(ped)) then
                        RemoveAllPedWeapons(ped, true)
                        if NetworkGetEntityIsNetworked(ped) then
                            DeleteNetworkedEntity(ped)
                        else
                            DeleteEntity(ped)
                        end
                    end
                end
        end)
        
        RegisterNetEvent("ZRQA3nmMqUBOIiKwH4I5:clearprops")
        AddEventHandler("ZRQA3nmMqUBOIiKwH4I5:clearprops", function()
                local objs = GetGamePool('CObject')
                for _, obj in ipairs(objs) do
                    if NetworkGetEntityIsNetworked(obj) then
                        DeleteNetworkedEntity(obj)
                        DeleteEntity(obj)
                    else
                        DeleteEntity(obj)
                    end
                end
                for object in EnumerateObjects() do
                    SetEntityAsMissionEntity(object, false, false)
                    DeleteObject(object)
                    if (DoesEntityExist(object)) then 
                        DeleteObject(object)
                    end
                end
        end)


        DeleteNetworkedEntity = function(entity)
            local attempt = 0
            while not NetworkHasControlOfEntity(entity) and attempt < 50 and DoesEntityExist(entity) do
                NetworkRequestControlOfEntity(entity)
                attempt = attempt + 1
            end
            if DoesEntityExist(entity) and NetworkHasControlOfEntity(entity) then
                SetEntityAsMissionEntity(entity, false, true)
                DeleteEntity(entity)
            end
        end
    
        local entityEnumerator = {
            __gc = function(enum)
            if enum.destructor and enum.handle then
              enum.destructor(enum.handle)
            end
            enum.destructor = nil
            enum.handle = nil
          end
        }
    
        local function EnumerateEntities(initFunc, moveFunc, disposeFunc)
          return coroutine.wrap(function()
            local iter, id = initFunc()
            if not id or id == 0 then
                disposeFunc(iter)
                return
            end
    
            local enum = {handle = iter, destructor = disposeFunc}
            setmetatable(enum, entityEnumerator)
    
            local next = true
            repeat
                coroutine.yield(id)
                next, id = moveFunc(iter)
            until not next
    
            enum.destructor, enum.handle = nil, nil
            disposeFunc(iter)
          end)
        end
    
        EnumerateObjects = function()
            return EnumerateEntities(FindFirstObject, FindNextObject, EndFindObject)
        end
    
    
end