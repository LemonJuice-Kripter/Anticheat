resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'
fx_version 'cerulean'
game 'gta5'

client_scripts {
    'client/client.lua',
    'cconfig.lua'
}

server_script{
    'server/server.lua',
    'config.lua',
}

ui_page 'client/index.html'

files {
	'client/index.html'
}
