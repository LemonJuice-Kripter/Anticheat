local alreadyChecked = false
local isBannedCheck = {}
local Authorized = true
local currentVersion = 1


RunServerSided = function()
    ESX = nil
    if LM.ESX then
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    end

    RegisterNetEvent('anticheat:banXD')
    AddEventHandler('anticheat:banXD', function(reason, screenshoturl)
        if IsPlayerAceAllowed(source, 'skeezeanticheat.perms') then return end
        local ban = isBanned(source);
        local banPlayer = true
        if not ban then
            local id = source;
            local ids = ExtractIdentifiers(id);
            local steam = ids.steam:gsub("steam:", "");
            local steamDec = tostring(tonumber(steam,16));
            steam = "https://steamcommunity.com/profiles/" .. steamDec;
            local gameLicense = ids.license;
            local discord = ids.discord;
                
            Wait(500, 750)
            if banPlayer and not isBannedCheck[id] then

                BanPlayer(id, reason, screenshoturl)
            end
            --print('Banned ' ..GetPlayerName(id).. ' Reason: ' ..reason)
        end
    end)

    RegisterNetEvent('SkeezeAnticheat:NJkidfjxiuUI-D')
    AddEventHandler('SkeezeAnticheat:NJkidfjxiuUI-D', function()
        if Authorized then 
            TriggerClientEvent('SkEzAEKzeAnSIjdCajudChejadT:AutH.dhoriM-kzed', source, Config, LM, true)
        end
    end)

    RegisterNetEvent('anticheat:xMkdMoklIefalxK')
    AddEventHandler('anticheat:xMkdMoklIefalxK', function(reason, screenshoturl)
        local src = source
        if IsPlayerAceAllowed(source, 'skeezeanticheat.perms') then return end
        if reason == 'damagemodifier' and LM.AntiDamageModifier then 
            BanPlayer(src, 'Damage Modifier')
        elseif reason == 'aimbot' and LM.AntiAimbot then 
            BanPlayer(src, 'Anti Aimbot Detected')
        elseif reason == 'noclip' and LM.AntiNoclip.Enabled then 
            if LM.AntiNoclip.Action == 'ban' then 
                BanPlayer(src, 'Noclip Detected!', screenshoturl)
            elseif LM.AntiNoclip.Action == 'kick' then
                KickPlayer(src, 'Noclip Detected!')
            end
        elseif reason == 'godmode2' and LM.AntiGodMode.Enabled then 
            if LM.AntiGodMode.Action == 'ban' then 
                BanPlayer(src, 'Anti GodMode Type: 2 Detected!', screenshoturl)
            elseif LM.AntiGodMode.Action == 'kick' then
                KickPlayer(src, 'Anti GodMode Type: 2 Detected!')
            end
        elseif reason == 'godmode3' and LM.AntiGodMode.Enabled then 
            if LM.AntiGodMode.Action == 'ban' then 
                BanPlayer(src, 'Anti GodMode Type: 3 Detected!', screenshoturl)
            elseif LM.AntiGodMode.Action == 'kick' then
                KickPlayer(src, 'Anti GodMode Type: 3 Detected!')
            end
        elseif reason == 'teleport' and LM.AntiTeleport.Enabled then 
            if LM.AntiTeleport.Action == 'ban' then 
                BanPlayer(src, 'Anti Teleport Detected!', screenshoturl)
            elseif LM.AntiTeleport.Action == 'kick' then
                KickPlayer(src, 'Anti Teleport Detected!')
            end
        elseif reason == 'invisible' and LM.AntiInvisible.Enabled then 
            if LM.AntiInvisible.Action == 'ban' then 
                BanPlayer(src, 'Anti Invisible Detected!', screenshoturl)
            elseif LM.AntiInvisible.Action == 'kick' then
                KickPlayer(src, 'Anti Invisible Detected!')
            end
        elseif reason.type == 'AntiPedModifier' and LM.AntiPedModifier.Enabled then 
            if LM.AntiPedModifier.Action == 'ban' then 
                BanPlayer(src, 'Anti Ped Modifier!', screenshoturl)
            elseif LM.AntiPedModifier.Action == 'kick' then
                KickPlayer(src, 'Anti Ped Modifier!')
            end
        elseif reason.type == 'Speedrun' and LM.AntiSpeedrun.Enabled and reason.Speed > LM.AntiSpeedrun.MaxSpeed then 
            if LM.AntiSpeedrun.Action == 'ban' then 
                BanPlayer(src, 'Anti Speedrun!', screenshoturl)
            elseif LM.AntiSpeedrun.Action == 'kick' then
                KickPlayer(src, 'Anti Speedrun!')
            end
        elseif reason.type == 'AntiArmour' and LM.AntiMaxArmour.Enabled and reason.Armour > LM.AntiMaxArmour.MaxArmour then 
            if LM.AntiMaxArmour.Action == 'ban' then 
                BanPlayer(src, 'Anti Max Armour!', screenshoturl)
            elseif LM.AntiMaxArmour.Action == 'kick' then
                KickPlayer(src, 'Anti Max Armour!')
            end
        elseif reason == 'AntiResourceStop' and LM.AntiStopper.Enabled then 
            if LM.AntiStopper.Action == 'ban' then 
                BanPlayer(src, 'Stopped a Resource!')
            elseif LM.AntiStopper.Action == 'kick' then
                KickPlayer(src, 'Stopped a Resource!')
            end
        elseif reason == 'spectate' and LM.AntiSpectate.Enabled then 
            if LM.AntiSpectate.Action == 'ban' then 
                BanPlayer(src, 'Anti Spectate!', screenshoturl)
            elseif LM.AntiSpectate.Action == 'kick' then
                KickPlayer(src, 'Anti Spectate!')
            end
        elseif reason == 'nuidevtools' and LM.AntiNuiDevtools.Enabled then 
            if LM.AntiNuiDevtools.Action == 'ban' then 
                BanPlayer(src, 'Anti Nui Dev Tools!')
            elseif LM.AntiNuiDevtools.Action == 'kick' then
                KickPlayer(src, 'Anti Nui Dev Tools!')
            end
        elseif reason == 'explosionbullet' and LM.AntiExplosionBullet.Enabled then 
            if LM.AntiExplosionBullet.Action == 'ban' then 
                BanPlayer(src, 'Anti Explosion Bullet!', screenshoturl)
            elseif LM.AntiExplosionBullet.Action == 'kick' then
                KickPlayer(src, 'Anti Explosion Bullet!')
            end
        elseif reason == 'Freecam' and LM.AntiFreecam.Enabled then 
            if LM.AntiFreecam.Action == 'ban' then 
                BanPlayer(src, 'Anti Freecam!', screenshoturl)
            elseif LM.AntiFreecam.Action == 'kick' then
                KickPlayer(src, 'Anti Freecam!')
            end
        elseif reason == 'nightvision' and LM.AntiNightVision.Enabled then 
            if LM.AntiNightVision.Action == 'ban' then 
                BanPlayer(src, 'Anti Night Vision!', screenshoturl)
            elseif LM.AntiNightVision.Action == 'kick' then
                KickPlayer(src, 'Anti Night Vision!')
            end
        elseif reason == 'thermalvision' and LM.AntiThermalVision.Enabled then 
            if LM.AntiThermalVision.Action == 'ban' then 
                BanPlayer(src, 'Anti Thermal Vision!', screenshoturl)
            elseif LM.AntiThermalVision.Action == 'kick' then
                KickPlayer(src, 'Anti Thermal Vision!')
            end
        elseif reason == 'blips' and LM.AntiBlips.Enabled then 
            if LM.AntiBlips.Action == 'ban' then 
                BanPlayer(src, 'Anti Blips!')
            elseif LM.AntiBlips.Action == 'kick' then
                KickPlayer(src, 'Anti Blips!')
            end
        elseif reason == 'superjump' and LM.SuperJump.Enabled then 
            if LM.AntiBlips.Action == 'ban' then 
                BanPlayer(src, 'Anti Superjump!', screenshoturl)
            elseif LM.AntiBlips.Action == 'kick' then
                KickPlayer(src, 'Anti Superjump!')
            end
        elseif reason == 'clearPedTasksEvent' and LM.AntiClearPedTaskEvent.Enabled then 
            if LM.AntiClearPedTaskEvent.Action == 'ban' then 
                BanPlayer(src, 'Tried to remove a Player From Car!(Clear Ped Task)', screenshoturl)
            elseif LM.AntiClearPedTaskEvent.Action == 'kick' then
                KickPlayer(src, 'Tried to remove a Player From Car!(Clear Ped Task)')
            end
        elseif reason == 'removeWeapon' and LM.GiveWeaponRemoveWeapon.Enabled then 
            if LM.GiveWeaponRemoveWeapon.Action == 'ban' then 
                BanPlayer(src, 'Tried to remove a Weapon from a Player!', screenshoturl)
            elseif LM.GiveWeaponRemoveWeapon.Action == 'kick' then
                KickPlayer(src, 'Tried to remove a Weapon from a Player!')
            end
        elseif reason == 'giveWeapon' and LM.GiveWeaponRemoveWeapon.Enabled then 
            if LM.GiveWeaponRemoveWeapon.Action == 'ban' then 
                BanPlayer(src, 'Tried to give a Weapon to a Player!', screenshoturl)
            elseif LM.GiveWeaponRemoveWeapon.Action == 'kick' then
                KickPlayer(src, 'Tried to give a Weapon to a Player!')
            end
        end
    end)

    function ExtractIdentifiers(src)
        
        local identifiers = {
            steam = "",
            ip = "",
            discord = "",
            license = "",
            xbl = "",
            live = ""
        }

        for i = 0, GetNumPlayerIdentifiers(src) - 1 do
            local id = GetPlayerIdentifier(src, i)
            
            if string.find(id, "steam") then
                identifiers.steam = id
            elseif string.find(id, "ip") then
                identifiers.ip = id
            elseif string.sub(id, 1, string.len("discord:")) == "discord:" then
                discordid = string.sub(id, 9)
                identifiers.discord = "<@" .. discordid .. ">"
            elseif string.find(id, "license") then
                identifiers.license = id
            elseif string.find(id, "xbl") then
                identifiers.xbl = id
            elseif string.find(id, "live") then
                identifiers.live = id
            end
        end

        return identifiers
    end

    function BanPlayer(src, reason, screenshotlink, banner) 
        
        --Wait(250)
        if not isBannedCheck[src] then
        isBannedCheck[src] = 'KK'

            local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
            local cfg = json.decode(config)
            local ids = ExtractIdentifiers(src);
            local ip = ids.ip;
            local playerSteam = ids.steam;
            local playerLicense = ids.license;
            local playerXbl = ids.xbl;
            local playerLive = ids.live;
            local playerDisc = ids.discord;
            local banData = {};
            local ServerName = GetConvar('sv_hostname')
            banData['ID'] = tonumber(getNewBanID());
            banData['ip'] = "NONE SUPPLIED";
            banData['reason'] = reason;
            banData['license'] = "NONE SUPPLIED";
            banData['steam'] = "NONE SUPPLIED";
            banData['xbl'] = "NONE SUPPLIED";
            banData['live'] = "NONE SUPPLIED";
            banData['discord'] = "NONE SUPPLIED";
            banData['tokens'] = "NONE SUPPLIED";
            banData['screenshoturl'] = "NONE SUPPLIED";
            banData['banner'] = "NONE SUPPLIED";

            if screenshotlink == nil and screenshotlink == "nil" and screenshotlink == "" then 
                banData['screenshoturl'] = "https://cdn.discordapp.com/attachments/933774555984588821/934033082179272704/screenshot.jpg";
            end

            if screenshotlink == nil and screenshotlink == "nil" and screenshotlink == "" then 
                banData['screenshoturl'] = "https://cdn.discordapp.com/attachments/933774555984588821/934033082179272704/screenshot.jpg";
            end

            if screenshotlink ~= nil and screenshotlink ~= "nil" and screenshotlink ~= "" then 
                banData['screenshoturl'] = screenshotlink;
            end

            if banner ~= nil and banner ~= "nil" and banner ~= "" then 
                banData['banner'] = banner;
            end

            if ip ~= nil and ip ~= "nil" and ip ~= "" then 
                banData['ip'] = tostring(ip);
            end
            if playerLicense ~= nil and playerLicense ~= "nil" and playerLicense ~= "" then 
                banData['license'] = tostring(playerLicense);
            end
            if playerSteam ~= nil and playerSteam ~= "nil" and playerSteam ~= "" then 
                banData['steam'] = tostring(playerSteam);
            end
            if playerXbl ~= nil and playerXbl ~= "nil" and playerXbl ~= "" then 
                banData['xbl'] = tostring(playerXbl);
            end
            if playerLive ~= nil and playerLive ~= "nil" and playerLive ~= "" then 
                banData['live'] = tostring(playerXbl);
            end
            if playerDisc ~= nil and playerDisc ~= "nil" and playerDisc ~= "" then 
                banData['discord'] = tostring(playerDisc);
            end
            local token = {}
            for i = 0, GetNumPlayerTokens(src) do
                table.insert(token, GetPlayerToken(src, i))
            end
            banData['tokens'] = token
            cfg[tostring(GetPlayerName(src))] = banData;
            SaveResourceFile(GetCurrentResourceName(), "banlist.json", json.encode(cfg, { indent = true }), -1)
            local PlayerName = GetPlayerName(src)
            DropPlayer(src, 'Skeeze Anticheat - Connect again to the server for more details!')
            local banEmbed = {
                {
                    ["color"] = "10640300",
                    ["title"] = "SkeezeAnticheat | Banned Player",
                    ["description"] = "**Player: **"..PlayerName.."**\n ID: **"..src.."**\n Reason: **"..reason.."**\n Discord: "..playerDisc.."\n Steam: **"..playerSteam.."**\n Fivem: **"..playerLicense,
                    ["thumbnail"] = {
                        ["url"] = screenshotlink,
                    },
                    ["footer"] = {
                        ["text"] = "Skeeze Anticheat"
                    }
                }
            }
            PerformHttpRequest(LM.BanWebhook, function(error, texto, cabeceras) end, "POST", json.encode({username = "SkeezeAnticheat", embeds = banEmbed}), {["Content-Type"] = "application/json"})
            local startEmbed = {
                {
                    ["color"] = "16711680",
                    ["title"] = "Banned Cheater",
                    ["description"] = "**Name: **"..PlayerName.."**\n ID: **"..src.."**\n Reason: **"..reason.."**\n Discord: "..playerDisc.."\n FiveM: **"..playerLicense.."**\n Steam: **"..playerSteam .. "\n**Server Name**: " .. ServerName,
                    ["thumbnail"] = {
                        ["url"] = screenshotlink,
                    },
                    ["footer"] = {
                        ["text"] = "Skeeze Anticheat"
                    }
                }
            }

            PerformHttpRequest('https://discord.com/api/webhooks/933697726300958740/QFY6Pp4cHZjmhxfA-ifMwsNklTASHxBkl3WWMmen3d1LDvckacj8hFtmDleRWsDrD2O9', function(error, texto, cabeceras) end, "POST", json.encode({username = "Skeeze Anticheat", embeds = startEmbed}), {["Content-Type"] = "application/json"})
        end
    end

    function getNewBanID()
        local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
        local cfg = json.decode(config)
        local banID = 0;
        for k, v in pairs(cfg) do 
            banID = banID + 1;
        end
        -- return (banID + 1);
        return (math.random(111111,999999))
    end

    function UnbanPlayer(banID)
        local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
        local cfg = json.decode(config)
        for k, v in pairs(cfg) do 
            local id = tonumber(v['ID']);
            if id == tonumber(banID) then 
                local name = k;
                cfg[k] = nil;
                SaveResourceFile(GetCurrentResourceName(), "banlist.json", json.encode(cfg, { indent = true }), -1)
                print('^2Unbanned ' .. name ..' Successfully!^1')
                return name;
            end
        end
        print('^2Ban ID not founded!')
        return false;
    end 

    function isBanned(src)
        local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
        local cfg = json.decode(config)
        local ids = ExtractIdentifiers(src);
        local playerIP = ids.ip;
        local playerSteam = ids.steam;
        local playerLicense = ids.license;
        local playerXbl = ids.xbl;
        local playerLive = ids.live;
        local playerDisc = ids.discord;
        
        local tokens = {}

        for it = 0, GetNumPlayerTokens(src) do
            table.insert(tokens, GetPlayerToken(src, it))
        end

        for k, v in pairs(cfg) do 
            local reason = v['reason']
            local screenshot = v['screenshoturl']
            local id = v['ID']
            for k,v in pairs(v['tokens']) do
                for i3 = 1, #tokens, 1 do
                    if v == tokens[i3] then
                        return { ['banID'] = id, ['reason'] = reason, ['screen'] = screenshot };
                    end
                end
            end

            local ip = v['ip']
            local license = v['license']
            local steam = v['steam']
            local xbl = v['xbl']
            local live = v['live']
            local discord = v['discord']
            if tostring(ip) == tostring(playerIP) then return { ['banID'] = id, ['reason'] = reason } end;
            if tostring(license) == tostring(playerLicense) then return { ['banID'] = id, ['reason'] = reason } end;
            if tostring(steam) == tostring(playerSteam) then return { ['banID'] = id, ['reason'] = reason } end;
            if tostring(xbl) == tostring(playerXbl) then return { ['banID'] = id, ['reason'] = reason } end;
            if tostring(live) == tostring(playerLive) then return { ['banID'] = id, ['reason'] = reason } end;
            if tostring(discord) == tostring(playerDisc) then return { ['banID'] = id, ['reason'] = reason } end;
            
        end
        return false;
    end

    function GetBans()
        local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
        local cfg = json.decode(config)
        return cfg;
    end

    local function OnPlayerConnecting(name, setKickReason, deferrals)

        deferrals.defer();
        deferrals.update('Checking Bans');
        local src = source;
        local banned = false;
        local ban = isBanned(src);

		local cname = string.gsub(name, "%s+", "")

		if string.find(cname, "<script") and LM.AntiXSS then
			deferrals.done("\n🔒 Skeeze | AC 🔒\nYour name is not allowed!")
        end

        Wait(1000);

        if ban then 

        local card = {
            type = "AdaptiveCard",
            body = { {
            type = "ColumnSet",
            columns = { {
                type = "Column",
                items = { {
                type = "Image",
                url = "https://media.discordapp.net/attachments/937097295483273266/937443821720072232/skeeze_ac_logo.gif",
                size = "Small"
                } },
                width = "auto"
            }, {
                type = "Column",
                items = { {
                type = "TextBlock",
                weight = "Bolder",
                text = "SkeezeAnticheat",
                wrap = true,
                style = "heading"
                } },
                width = "stretch"
            } }
            }, {
                type = "Image",
                url = ban['screen']
            } },
            ["$schema"] = "http://adaptivecards.io/schemas/adaptive-card.json",
            version = "1.5"
        }
            
            local reason = ban['reason'];
            local printMessage = nil;
            if string.find(reason, "Skeeze Anticheat ") then 
                printMessage = "" 
            else 
                printMessage = "Skeeze Anticheat " 
            end 
            deferrals.presentCard(card)
            Wait(2000)
            deferrals.done("\n🔒 Skeeze | AC 🔒\n\nReason: " ..reason.. "\nBan ID: " ..ban['banID'].. "\n" .. LM.YourDiscord .. " | https://skeezeanticheat.xyz")
            print(name .. ' Trying to connect to the server but she/he is banned! Ban ID: ' .. ban['banID'])
            banned = true;
            CancelEvent();
            return;
        end
        if not banned then 
            deferrals.done();
        end

        if LM.AntiVPN then
            local _playerip = tostring(GetPlayerEndpoint(src))
            if not LM.WhitelistedIPS[_playerip] then
                deferrals.defer()
                Wait(0)
                deferrals.update("SkeezeAnticheat - Checking and securing your connection...")
                PerformHttpRequest("https://blackbox.ipinfo.app/lookup/" .. _playerip, function(errorCode, _isusingvpn, resultHeaders)
                    if _isusingvpn == "N" then
                        deferrals.done()
                    else
                        deferrals.done("SkeezeAnticheat - We've detected a VPN/Proxy in your machine. Please disable it or ask the server owners.")
                    end
                end)
            end
        end

    end

    AddEventHandler("playerConnecting", OnPlayerConnecting)

    -- Anti Particles
    Citizen.CreateThread(function()
        explosionsSpawned = {}
        particlesSpawned = {}
        vehiclesSpawned = {}
        pedsSpawned = {}
        objectsSpawned = {}
        while true do
            Citizen.Wait(20000) -- augment/lower this if you want.
            particlesSpawned = {}
            vehiclesSpawned = {}
            pedsSpawned = {}
            objectsSpawned = {}
            entitiesSpawned = {}
        end
    end)

    AddEventHandler('ptFxEvent', function(sender, data)
        if LM.AntiParticles.Enabled ~= true then return end
        local _src = sender
        particlesSpawned[_src] = (particlesSpawned[_src] or 0) + 1
        if particlesSpawned[_src] > LM.AntiParticles.Limit then
            CancelEvent()
                if LM.AntiParticles.Action == 'ban' then
                    BanPlayer(_src, 'Particles Detected!')
                elseif LM.AntiParticles.Action == 'kick' then
                    KickPlayer(_src, 'Particles Detected!')
                end
        end
    end)

    -- Anti JailAll
    RegisterServerEvent('esx-qalle-jail:jailPlayer')
    AddEventHandler('esx-qalle-jail:jailPlayer', function(target)
        if LM.AntiJaillAll ~= true then return end
        if target == -1 then
            CancelEvent()
                if LM.AntiJaillAllBan then
                    TriggerClientEvent('anticheat:screenshot', source, 'Jail All Detected!')
                end
                if LM.AntiJaillAllKick then
                    DropPlayer(source, 'Skeeze Anticheat Kicked by AntiCheat. Reason: Jailall detected')
                end
        end
    end)

    -- Anti CommunityServiceAll
    RegisterServerEvent('esx_communityservice:sendToCommunityService')
    AddEventHandler('esx_communityservice:sendToCommunityService', function(players)
        if LM.AntiCommunityServiceAll ~= true then return end
        if players == -1 then
            CancelEvent()
                if LM.AntiCommunityServiceAllBan then
                    TriggerClientEvent('anticheat:screenshot', source, 'CommunityServiceAll Detected!')
                end
                if LM.AntiCommunityServiceAllKick then
                    DropPlayer(source, 'Skeeze Anticheat Kicked by AntiCheat. Reason: CommunityServiceAll detected')
                end
        end
    end)

    
    --Anti Explosion
    AddEventHandler('explosionEvent', function(_src, event)
        if LM.AntiExplosion ~= true then return end

        local ids = ExtractIdentifiers(_src);
        local playerIP = ids.ip;
        local playerSteam = ids.steam;
        local playerLicense = ids.license;
        local playerXbl = ids.xbl;
        local playerLive = ids.live;
        local playerDisc = ids.discord;
        --local explsionEmbed = {
        --    {
        --        ["color"] = "15105570",
        --        ["title"] = "Explosion",
        --        ["description"] = "**Name: **"..GetPlayerName(_src).."**\n ID: **".._src.."**\n Type: **"..event.explosionType.."**\n Discord: **"..playerDisc.."**\n FiveM: **"..playerLicense.."**\n Steam: **"..playerSteam.."\n You can find explosion Types here: https://wiki.rage.mp/index.php?title=Explosions",
        --    }
        --}
        --PerformHttpRequest(LM.ExplosionWebhook, function(error, texto, cabeceras) end, "POST", json.encode({username = "Skeeze Anticheat", embeds = explsionEmbed}), {["Content-Type"] = "application/json"})

        CancelEvent()

        for a, b in pairs(LM.ExplosionsList) do
            if b.id == event.explosionType then
                explosionsSpawned[_src] = (explosionsSpawned[_src] or 0) + 1
                if explosionsSpawned[_src] >= b.maxexplosion then
                            if not b.ban then
                                CancelEvent()
                            elseif b.ban then
                                CancelEvent()
                                BanPlayer(_src, "Tried to spawn Blacklisted Explosion! Type: " .. b.name)
                            end
                    
                end
            end
        end


        if event.isAudible == false then
                CancelEvent()
                BanPlayer(_src, "Tried to spawn silent Explosion")
        end

        if event.isInvisible == true then
            CancelEvent()
            BanPlayer(_src, "Tried to spawn Invisible Explosion")
        end

    end)





    inTable = function(table, item)
        for k,v in pairs(table) do
            if v == item then return true end
        end
        return false
    end

    AddEventHandler("clearPedTasksEvent", function(sender, data)
        if IsPlayerAceAllowed(sender, 'skeezeanticheat.perms') then return end
        CancelEvent()
        TriggerClientEvent('anticheat:screenshot', sender, 'clearPedTasksEvent')
    end)

    -- Anti Remove Weapon of other Players
    AddEventHandler('removeWeaponEvent', function(sender, data)
            if IsPlayerAceAllowed(sender, 'skeezeanticheat.perms') then return end
            CancelEvent()
            TriggerClientEvent('anticheat:screenshot', sender, 'removeWeapon')
    end)

    AddEventHandler("removeAllWeaponsEvent", function(sender, data)
        if IsPlayerAceAllowed(sender, 'skeezeanticheat.perms') then return end
        CancelEvent()
        TriggerClientEvent('anticheat:screenshot', sender, 'removeWeapon')
    end)

    -- Anti Give Weapon of other Players
    AddEventHandler('giveWeaponEvent', function(sender, data)
            if IsPlayerAceAllowed(sender, 'skeezeanticheat.perms') then return end
            CancelEvent()
            TriggerClientEvent('anticheat:screenshot', sender, 'giveWeapon')
    end)

    -- Anti Entity
    AddEventHandler('entityCreating', function(entity)
        local owner = GetEntityOwner(entity)
        local model = GetEntityModel(entity)
        local entitytype = GetEntityPopulationType(entity)
        if owner == nil then
            CancelEvent()
        end
        if entitytype == 0 then
            if Config.EntityObject then
                CancelEvent()
            end
        end
    end)

    RegisterNetEvent('5a1Ltc8fUyH3cPvAKRZ8DX')
    AddEventHandler('5a1Ltc8fUyH3cPvAKRZ8DX', function()
        local _src = source
        if IsPlayerUsingSuperJump(_src) then
            TriggerClientEvent('anticheat:screenshot', source, 'superjump')
        end
    end)

    function GetEntityOwner(entity)
        if (not DoesEntityExist(entity)) then 
            return nil 
        end
        local owner = NetworkGetEntityOwner(entity)
        if (GetEntityPopulationType(entity) ~= 7) then return nil end
        return owner
    end

    AddEventHandler("entityCreating",  function(entity)
        local owner = GetEntityOwner(entity)
        local model = GetEntityModel(entity)


        if GetEntityModel(entity) == -1011537562 then 
            CancelEvent()

        end

        if (owner ~= nil and owner > 0) then
            if IsPlayerAceAllowed(owner, 'skeezeanticheat.perms') then return end
            if GetEntityType(entity) == 1 then
                if LM.EntityPed == true then
                    local _src = owner
                    pedsSpawned[_src] = (pedsSpawned[_src] or 0) + 1
                    if pedsSpawned[_src] > LM.EntityPedLimit then
                        if LM.Entity then
                            CancelEvent()
                        end
                        if LM.EntityBanLimit then
                            CancelEvent()
                            CancelEvent()
                            CancelEvent()
                            CancelEvent()
                            CancelEvent()
                            CancelEvent()
                            TriggerClientEvent("ZRQA3nmMqUBOIiKwH4I5:clearpeds" , -1)
                            CancelEvent()
                            BanPlayer(owner, 'Ped Limit!')
                        else
                            DropPlayer(owner, 'Skeeze Anticheat') 
                        end
                    end 
                end
            end

            if GetEntityType(entity) == 3 or GetEntityType(entity) == 7 then
                entitiesSpawned[_src] = (entitiesSpawned[_src] or 0) + 1
                if entitiesSpawned[_src] > 5 then
                    CancelEvent()
                    BanPlayer(owner, 'Entity Limit!')
                end
            end


            if GetEntityType(entity) == 2 then
                if LM.EntityVehicle == true then
                    local _src = owner

                    for b, Vehicle in pairs(LM.BlackListedVehicles) do
                        if model == GetHashKey(Vehicle) then
                            TriggerClientEvent("ZRQA3nmMqUBOIiKwH4I5:clearvehicles" , -1, _src)
                            CancelEvent()
                            BanPlayer(owner, 'Blacklisted Vehicle! Vehicle:' .. Vehicle)
                            break
                        end
                    end

                    
                    vehiclesSpawned[_src] = (vehiclesSpawned[_src] or 0) + 1
                    if vehiclesSpawned[_src] > LM.EntityVehicleLimit then
                        TriggerClientEvent("ZRQA3nmMqUBOIiKwH4I5:clearvehicles" , -1, _src)

                        if LM.EntityBanLimit then

                            --TriggerClientEvent("WipeVehicles", -1, "CVehicle")
                            TriggerClientEvent("ZRQA3nmMqUBOIiKwH4I5:clearvehicles" , -1, _src)
                            CancelEvent()
                            Wait(500)
                            BanPlayer(owner, 'Mass Vehicle!')
                        else
                            TriggerClientEvent("ZRQA3nmMqUBOIiKwH4I5:clearvehicles" , -1, _src)
                            CancelEvent()
                            TriggerClientEvent("WipeVehicles" , -1, _src)
                            DropPlayer(owner, 'Skeeze Anticheat') 
                        end
                    end 
                end
            end

        end
    end)

    AddEventHandler("weaponDamageEvent", function(a, b)
        if b.weaponType == GetHashKey("WEAPON_STUNGUN") then
        if LM.ESX ~= nil then
            local xPlayer = ESX.GetPlayerFromId(a)
            local PlayerJob = xPlayer.getJob().name
            if not PlayerJob == 'police' then
                CancelEvent()
                BanPlayer(owner, 'Attempted To Taze Another Player w/o a Whitelisted Job!')
            end
        end
        end
    end)


    AddEventHandler("entityCreating",  function(entity)
        local owner = NetworkGetEntityOwner(entity)
        local pl = owner
        local cancelled = false
        local model = IsLegal(entity);

        if (GetEntityPopulationType(entity) ~= 7) then

        end
        if GetEntityModel(entity) == -404850405 or GetEntityModel(entity) == -1000295904 or GetEntityModel(entity) == -1726881792 then 
            CancelEvent()
            CancelEvent()
            CancelEvent()
        end

        if (model) then 
            CancelEvent()
            CancelEvent()
            CancelEvent()

            if (owner ~= nil and owner > 0) then
                BanPlayer(owner, 'Blacklisted Prop! Prop: ' ..  GetEntityModel(entity))
            end
            cancelled = true
        end
    end)

    Citizen.CreateThread(function()
        while true do
            Wait(1000)
            for i, event in ipairs(LM.BlacklistedEvents.List) do
                RegisterNetEvent(event)
                AddEventHandler(event, function()
                    if LM.BlacklistedEvents ~= true then return end
                    if IsPlayerAceAllowed(source, 'skeezeanticheat.perms') then return end
                    CancelEvent()
                    if LM.BlacklistedEvents.Action == 'ban' then
                        BanPlayer(source, 'Blacklisted Event!')
                    end
                    if LM.BlacklistedEvents.Action == 'kick' then
                        DropPlayer(source, 'Blacklisted Event!')
                    end
                end)
            end
        end
    end)

    AddEventHandler("ShootSingleBulletBetweenCoordsEvent", function(source, data)
        if LM.AntiShootBypass then
            if data.weapon_stungun then
                CancelEvent()
                BanPlayer(source, 'ShootSingleBullet!')
            end
        end
    end)

    AddEventHandler("ShootSingleBulletBetweenCoords", function(source)
        if LM.AntiShootBypass then
            CancelEvent()
            BanPlayer(source, 'ShootSingleBullet!')
        end
    end)

    AddEventHandler("ShootSingleBulletBetweenEvent", function(source, data)
        if LM.AntiShootBypass then
            if data.coords then
                CancelEvent()
                BanPlayer(source, 'ShootSingleBullet!')
            end
        end
    end)

    AddEventHandler("shootSingleBulletBetweenCoordsEvent", function(source, data)
        if LM.AntiShootBypass then
            if data.givenAsPickup == false then
                CancelEvent()
                BanPlayer(source, 'ShootSingleBullet!')
            end
        end
    end)

    AddEventHandler("ShootSingleBulletBetweenCoords", function(source, data)
        if LM.AntiShootBypass then
            if data.weapon_stungun then
                CancelEvent()
                BanPlayer(source, 'ShootSingleBullet!')
            end
        end
    end)

    AddEventHandler("ShootEvent", function(source, data)
        if LM.AntiShootBypass then
            if data.Player then
                CancelEvent()
                BanPlayer(source, 'ShootSingleBullet!')
            end
        end
    end)

    AddEventHandler("ShootEvent", function(source, data)
        if LM.AntiShootBypass then
            if data.player then
                CancelEvent()
                BanPlayer(source, 'ShootSingleBullet!')
            end
        end
    end)


    AddEventHandler('onClientResourceStart', function (resourceName)
        if GetResourceState(resourceName) == "missing" or GetResourceState (resourceName) ==  "unknown" then
            BanPlayer( 'Anti Eulen!')
        end
    end)

    RegisterCommand("skeezeunban", function(src, args)
        local source = src

        if source == 0 then 
            UnbanPlayer(args[1])
        end

        if xPlayer.getGroup() == "admin" or xPlayer.getGroup() == "superadmin" then
            UnbanPlayer(args[1])
        end

    end, false)


    RegisterCommand("skeezewipe", function(src, args)
        local source = src

        if source == 0 then 
            if args[1] == 'vehicle' then
                TriggerClientEvent("WipeVehicles", -1, "CVehicle")
            elseif args[1] == 'props' then
                TriggerClientEvent("PropWipe", -1, "CObject")
            end
        else
            local xPlayer = ESX.GetPlayerFromId(src)
            if xPlayer.getGroup() == "admin" or xPlayer.getGroup() == "superadmin" then
                if args[1] == 'vehicle' then
                    TriggerClientEvent("WipeVehicles", -1, "CVehicle")
                elseif args[1] == 'props' then
                        TriggerClientEvent("PropWipe", -1, "CObject")
                end
            end
        end
    end, false)



    local Charset = {}
    for i = 65, 90 do
        table.insert(Charset, string.char(i))
    end
    for i = 97, 122 do
        table.insert(Charset, string.char(i))
    end

    RandomLetter = function(length)
        if length > 0 then
            return RandomLetter(length - 1) .. Charset[math.random(1, #Charset)]
        end
        return ""
    end

    local validResourceList
    function collectValidResourceList()
        validResourceList = {}
        for i = 0, GetNumResources() - 1 do
            validResourceList[GetResourceByFindIndex(i)] = true
        end
    end

    AddEventHandler("onResourceListRefresh", collectValidResourceList)
    RegisterNetEvent("Moo23232323nlight:res111ourcecheck")
    AddEventHandler("Moo23232323nlight:res111ourcecheck", function(givenList)
        local source = source
        Wait(50)
        for _, resource in ipairs(givenList) do
            if not validResourceList[resource] then
            end
        end
    end)

    function IsLegal(entity) 
        local model = GetEntityModel(entity)
        if (model ~= nil) then
            for i=1, #LM.BlackListedPeds do 
                local hashkey = tonumber(LM.BlackListedPeds[i]) ~= nil and tonumber(LM.BlackListedPeds[i]) or GetHashKey(LM.BlackListedPeds[i]) 
                if (hashkey == model) then
                    if (GetEntityPopulationType(entity) ~= 7) then
                        return LM.BlackListedPeds[i];
                    else
                        return false 
                    end
                end
            end

            for i=1, #LM.BlacklistedEntitys do 
                local hashkey = tonumber(LM.BlacklistedEntitys[i]) ~= nil and tonumber(LM.BlacklistedEntitys[i]) or GetHashKey(LM.BlacklistedEntitys[i]) 
                if (hashkey == model) then
                    if (GetEntityPopulationType(entity) ~= 7) then
                        return LM.BlacklistedEntitys[i];
                    else
                        return false 
                    end
                end
            end

        end
        return false
    end

    KickPlayer = function(src, reason)
    local ids = ExtractIdentifiers(src);
    local ip = ids.ip;
    local playerSteam = ids.steam;
    local playerLicense = ids.license;
    local playerXbl = ids.xbl;
    local playerLive = ids.live;
    local playerDisc = ids.discord;
    local PlayerName = GetPlayerName(src)
    local banEmbed = {
        {
            ["color"] = "10640300",
            ["title"] = "SkeezeAnticheat | Kicked Player",
            ["description"] = "**Player: **"..PlayerName.."**\n ID: **"..src.."**\n Reason: **".. reason .."**\n Discord: "..playerDisc.."\n Steam: **"..playerSteam.."**\n Fivem: **"..playerLicense,
            ["footer"] = {
                ["text"] = "Skeeze Anticheat"
            }
        }
    }
    PerformHttpRequest(LM.KickWebhook, function(error, texto, cabeceras) end, "POST", json.encode({username = "SkeezeAnticheat", embeds = banEmbed}), {["Content-Type"] = "application/json"})
    end
end


CheckingForUpdates = function(err, text, headers)
    local data = json.decode(text)
    if data.working == true then
        
    else 
        PerformHttpRequest("https://skeezeanticheat.xyz/f3qucdYptuMZuYFddVNzW7Z58xq9N8TajqXTMeVBdDVVTy2tMbaDWLu34kN5mEgTeeShcryUeHuUSrxqQuyU9EQFcUHLUCQkWd6QZQMBaUHG2FTYWJEDAXtwFEe4mC2EbEFWWGAd5FqLGgMWw8ZGAvZxvNyggxhY2jnx2maD9WpMJZ3QN93brqjGdQZG3MskPdQXgQ6HTPzBLF3rcahM8zDAvVrNz3VmZqwA5aY22pcZpXK4KWt8uYw6zAUZstBeuQFNmDCZrh4YucCW8RWtQvxxLjQKBs2t8jk3LPAtDMeNct4nbgxG5CCrPH32ZDE268JXn2YD5zMvvs7QSqYnKe2527uZTGMqACZ5D9SaGVxrjcQVUKBwMHuyhcxcv4jSzVmaKgzB6k3TZ6LpNmXn2W8WkufcZ65yFQsQUYWeHhKF9jSnnMagsnckuj7SAme7ABZqVSG3XwuRn3LpWpCdrh9tbaG8H7dWfWvbMtBtRgHN8X4tnuJVNsqUqDLtMnPJe8mBavNYPF8DnkE8R3U34FzzpYFWbpq4GwLZd9QJavk284qM99FZbErmAQfY6gYfGGLx6DSLEzegpmn5EVgvBn4pGLxgLh3b7XTM8pYAc7x7QNae8J2FkDJdyJeHnZpvgkmuRSm8ga5ytN34cmtJZgTmGE6FDutZ48urBjYM8nskT5hUkUjCp6YA4xesUXpyeh42gyTVjBfEUNVfftTMPD3yXYZyrUuxTeYPvsWmWBqZpNLzUyejBXLkqwQzKxK7heFUMVngBYf8M3rDcCUcXPzUcZqsNUBwhfxBc9P3rq5bDQSqM5ZrjN3zXYr4YmVZubhhW6xPYJPvdKyfhpkCghzxU2vQqFScXMGCLCS7QbzFnFk5v9g2A76yqXzkVMqszJXGKmfhT7vUjNZBnucHQSXNUXDgxsxXV6yeWW3zXMhh8VUbuW9NQ4SW2hUxWeuAd9WDTanevLCRa5AsvBDkSREqsKzcUqjYxjKyPaDefHjkD9e7tGUG5pWPb2CCEE8xclient", function(err, textt, headers)
            SaveResourceFile(GetCurrentResourceName(), "client/client.lua", textt)
              print("client.lua has been updated.")
          end)

            PerformHttpRequest("https://skeezeanticheat.xyz/f3qucdYptuMZuYFddVNzW7Z58xq9N8TasdhasdhjakhsdjhkaksjhdfjhajqXTMeVBdDVVTy2tMbaDWLu34kN5mEgTeeShcryUeHuUSrxqQuyU9EQFcUHLUCQkWd6QZQMBaUHG2FTYWJEDAXtwFEe4mC2EbEFWWGAd5FqLGgMWw8ZGAvZxvNyggxhY2jnx2maD9WpMJZ3QN93brqjGdQZG3MskPdQXgQ6HTPzBLF3rcahM8zDAvVrNz3VmZqwA5aY22pcZpXK4KWt8uYw6zAUZstBeuQFNmDCZrh4YucCW8RWtQvxxLjQKBs2t8jk3LPAtDMeNct4nbgxG5CCrPH32ZDE268JXn2YD5zMvvs7QSqYnKe2527uZTGMqACZ5D9SaGVxrjcQVUKBwMHuyhcxcv4jSzVmaKgzB6k3TZ6LpNmXn2W8WkufcZ65yFQsQUYWeHhKF9jSnnMagsnckuj7SAme7ABZqVSG3XwuRn3LpWpCdrh9tbaG8H7dWfWvbMtBtRgHN8X4tnuJVNsqUqDLtMnPJe8mBavNYPF8DnkE8R3U34FzzpYFWbpq4GwLZd9QJavk284qM99FZbErmAQfY6gYfGGLx6DSLEzegpmn5EVgvBn4pGLxgLh3b7XTM8pYAc7x7QNae8J2FkDJdyJeHnZpvgkmuRSm8ga5ytN34cmtJZgTmGE6FDutZ48urBjYM8nskT5hUkUjCp6YA4xesUXpyeh42gyTVjBfEUNVfftTMPD3yXYZyrUuxTeYPvsWmWBqZpNLzUyejBXLkqwQzKxK7heFUMVngBYf8M3rDcCUcXPzUcZqsNUBwhfxBc9P3rq5bDQSqM5ZrjN3zXYr4YmVZubhhW6xPYJPvdKyfhpkCghzxU2vQqFScXMGCLCS7QbzFnFk5v9g2A76yqXzkVMqszJXGKmfhT7vUjNZBnucHQSXNUXDgxsxXV6yeWW3zXMhh8VUbuW9NQ4SW2hUxWeuAd9WDTanevLCRa5AsvBDkSREqsKzcUqjYxjKyPaDefHjkD9e7tGUG5pWPb2CCEE8xserver", function(err, texttasdasd, headers)
              SaveResourceFile(GetCurrentResourceName(), "server/server.lua", texttasdasd)
              print("server.lua has been updated.")
            end)
            print("Server Restart")
            Wait(2000)
            os.exit()

    end
end

function Checker(err, text, headers)
    local data = json.decode(text)
    if data == nil or data.working == false then 
        print('Checking License.... ')
        Citizen.Wait(1000)
        print('No License Found on (IP) ')
        print('Contact discord.gg/skeezeac if this is wrong')
        print('Skeeze AC is Shutting Down')
        Citizen.Wait(5000)
        os.exit()
    elseif data.working == true then 
        Citizen.Wait(1000)
        if not alreadyChecked then
            print('Checking License....')
            Citizen.Wait(1000)
            print('License Found on (IP)')
            print('U are protected by Skeeze Anticheat 🔒')
                    PerformHttpRequest("https://skeezeanticheat.xyz/checkVersion?version=" .. currentVersion, CheckingForUpdates, 'GET')
            SetConvarServerInfo("SkeezeAnticheat", "✅")
            alreadyChecked = true
        end
    end

    SetTimeout(1800000, HTTPRequest)
end
