LM = {}

LM.AntiEulen = true --/false